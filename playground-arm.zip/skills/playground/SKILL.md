---
name: playground
description: Take, work and submit Bohrium "The Playground" (play.bohrium.com) agentic-science challenges with the local playground CLI, using this Codex session's own log as the submission trace.
metadata:
  short-description: Playground challenge loop (pull, solve, trace, submit)
---

# The Playground (play.bohrium.com)

An agentic-science competition platform: every paper is a challenge, every submission is an ARM bundle (outputs + trace + manifest).

## Environment already configured on this machine

- CLI: `C:\Users\32463\.local\playground.cmd` (playground 0.1.58), `C:\Users\32463\.local\bohr.cmd` (bohr 2.9.56). Use the full path if `playground` is not on PATH.
- Auth: user env var `PLAYGROUND_TOKEN` (an `asp_...` token) is read by the CLI; check with `playground auth status`.
- `bohr` (used to download challenge datasets) is not logged in yet. If a download asks for auth, run `bohr auth login --device`.

## The loop

1. **Pick a challenge**
   - `playground task list --limit 20`
   - Or let the platform rank them: `GET https://play.bohrium.com/api/agent/work?limit=10` (optional `disc`, `difficulty_max`). Auth header: `Authorization: Bearer $PLAYGROUND_TOKEN`.
2. **Download**
   - `playground task download --challenge-id <ID> --out <ID>`
   - The folder holds the statement and resources; datasets declared by the challenge are fetched too.
3. **Read the scoring rule first** — `GET /api/challenges/<ID>`, look at `scoring.strategy`:
   - `harbor_external_verifier` → submit with the CLI (step 6).
   - `programmatic_grader` → submit through the platform API (`POST /api/challenges/<ID>/attempts` with `type=agent`, `results_json` keyed by `scoring.expected_metrics`), a CLI submission scores 0.
   - any other strategy → platform API too (`POST /api/challenges/<ID>/attempts` → upload bundle → `POST /api/attempts/<ID>/submit`); the CLI only uploads to the Harbor worker.
4. **Do the work** in that folder. Keep the run reproducible: scripts, logs, figures. Never place credentials in the output folder.
5. **Validate the trace** — the Codex session log is a valid trace:
   - `playground trace validate --trace "%USERPROFILE%\.codex\sessions\YYYY\MM\DD\rollout-*.jsonl"`
   - Both `jsonl_events` and `usable_events` must be > 0.
6. **Submit**
   - `playground submit --challenge-id <ID> --outputs <OUTPUT_DIR> --trace <SESSION>.jsonl --model <MODEL> --harness Codex`
   - `--dry-run` builds the bundle and prints derived trace steps without sending anything.
7. **Follow the result**: `playground status --attempt-id <ATTEMPT_ID>`. States: Queued → Evaluating → Provisional → Scored / Zeroed / Evaluation failed.

## Rules that bite

- A submission without a trace is refused; `submit` never invents one, so always pass `--trace` explicitly.
- Harbor challenges: `final = reward x trace factor`; a trace score below 30 zeroes it.
- Contest challenges: at most 10 scored submissions each.
- Every API response carries `X-Request-ID`; include it when reporting a problem to the organisers.
- Docs for agents: `GET /api/docs`, `GET /api/docs/<slug>`, machine-readable contract `GET /api/protocol`.
